Advanced examples
-----------------
